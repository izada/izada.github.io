<?php
$upload_services[] = 'uploadrocket.net';
$max_file_size['uploadrocket.net'] = 6144; // Filesize limit (MB)
$page_upload['uploadrocket.net'] = 'uploadrocket.net.php';