<?php 
$upload_services[] = 'filecad.com';
$max_file_size['filecad.com'] = 100;
$page_upload['filecad.com'] = 'filecad.com.php';
?>