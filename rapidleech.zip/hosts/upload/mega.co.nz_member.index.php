<?php
$upload_services[] = 'mega.co.nz_member';
$max_file_size['mega.co.nz_member'] = false;
$page_upload['mega.co.nz_member'] = 'mega.co.nz_member.php';
?>