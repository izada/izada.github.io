<?php
$upload_services[] = 'anafile.com';
$max_file_size['anafile.com'] = 1024;
$page_upload['anafile.com'] = 'anafile.com.php';
?>