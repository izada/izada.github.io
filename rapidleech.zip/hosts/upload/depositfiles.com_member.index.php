<?php
$upload_services[] = 'depositfiles.com_member';
$max_file_size['depositfiles.com_member'] = 10240;
$page_upload['depositfiles.com_member'] = 'depositfiles.com_member.php';