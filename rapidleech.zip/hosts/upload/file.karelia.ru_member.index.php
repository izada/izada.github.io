<?php
$upload_services[] = 'file.karelia.ru_member';
$max_file_size['file.karelia.ru_member'] = 25;
$page_upload['file.karelia.ru_member'] = 'file.karelia.ru_member.php';
?>